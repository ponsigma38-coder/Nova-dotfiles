#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
CONFIG="${XDG_CONFIG_HOME:-$HOME/.config}"
STAMP="$(date +%Y%m%d-%H%M%S)"
BACKUP="$HOME/.local/state/nova-dotfiles-backup/$STAMP"

ok(){ printf '\033[1;32m[OK]\033[0m %s\n' "$*"; }
warn(){ printf '\033[1;33m[WARN]\033[0m %s\n' "$*"; }
die(){ printf '\033[1;31m[ERROR]\033[0m %s\n' "$*" >&2; exit 1; }

[[ -d "$ROOT" ]] || die "Project directory not found."
command -v pacman >/dev/null 2>&1 || die "This installer targets Arch Linux / EndeavourOS."

if command -v paru >/dev/null 2>&1; then
  AUR_HELPER=paru
elif command -v yay >/dev/null 2>&1; then
  AUR_HELPER=yay
else
  AUR_HELPER=""
fi

PACKAGES=(niri waybar foot fuzzel mako swaybg brightnessctl playerctl wireplumber pavucontrol ttf-jetbrains-mono-nerd ttf-font-awesome papirus-icon-theme)
MISSING=()
for p in "${PACKAGES[@]}"; do
  pacman -Q "$p" >/dev/null 2>&1 || MISSING+=("$p")
done

if ((${#MISSING[@]})); then
  printf 'Packages to install: %s\n' "${MISSING[*]}"
  if [[ -n "$AUR_HELPER" ]]; then
    "$AUR_HELPER" -S --needed "${MISSING[@]}"
  else
    warn "Neither paru nor yay found; using sudo pacman."
    sudo pacman -S --needed "${MISSING[@]}"
  fi
else
  ok "All listed packages are already installed."
fi

mkdir -p "$BACKUP" "$CONFIG"
for name in niri waybar fuzzel foot mako; do
  if [[ -e "$CONFIG/$name" ]]; then
    cp -a "$CONFIG/$name" "$BACKUP/"
    ok "Backed up $CONFIG/$name"
  fi
done

install -d "$CONFIG/niri" "$CONFIG/waybar" "$CONFIG/fuzzel" "$CONFIG/foot" "$CONFIG/mako"
install -m 0644 "$ROOT/niri/config.kdl" "$CONFIG/niri/config.kdl"
install -m 0644 "$ROOT/waybar/config.jsonc" "$CONFIG/waybar/config.jsonc"
install -m 0644 "$ROOT/waybar/style.css" "$CONFIG/waybar/style.css"
install -m 0644 "$ROOT/fuzzel/fuzzel.ini" "$CONFIG/fuzzel/fuzzel.ini"
install -m 0644 "$ROOT/foot/foot.ini" "$CONFIG/foot/foot.ini"
install -m 0644 "$ROOT/mako/config" "$CONFIG/mako/config"

mkdir -p "$HOME/Pictures/Wallpapers"
if [[ ! -e "$HOME/Pictures/Wallpapers/nova.jpg" ]]; then
  warn "Add your own wallpaper at ~/Pictures/Wallpapers/nova.jpg; no wallpaper image is bundled."
fi

for script in "$ROOT/scripts/install.sh"; do
  bash -n "$script" || die "Shell syntax check failed: $script"
done

ok "Nova starter configuration installed."
printf 'Backup: %s\n' "$BACKUP"
warn "Review Niri config compatibility with your installed Niri version before logging out."
