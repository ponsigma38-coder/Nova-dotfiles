#!/usr/bin/env bash
set -euo pipefail
cat <<'EOF'
Nova Dotfiles does not automatically delete configs during uninstall.
Restore your own backup from ~/.local/state/nova-dotfiles-backup/ after reviewing it.
This script intentionally makes no destructive changes.
EOF
