# Nova Dotfiles

A custom Niri desktop setup for Arch Linux and EndeavourOS, inspired by the visual style of HyDE.

## Included

- Niri configuration with practical keybindings
- Bottom Waybar configuration
- Fuzzel launcher and Foot terminal settings
- Wallpaper and theme helper scripts
- Installer that prefers `paru`, then `yay`, then `pacman`
- Backups of selected existing configuration folders

Nova Dotfiles is an independent project inspired by HyDE, not an official HyDE port. It is a starting point and has not been runtime-tested on a clean EndeavourOS installation. Review scripts before running them.

## Install

```bash
git clone https://github.com/ponsigma38-coder/Nova-dotfiles.git
cd Nova-dotfiles
less scripts/install.sh
chmod +x scripts/install.sh
./scripts/install.sh
```

If the repository is still empty, download the project archive and run the installer from the extracted directory instead.

## Notes

- The installer backs up selected existing configuration directories before copying files.
- NVIDIA/Wayland behavior depends on your installed driver and system configuration.
- Keep a working TTY/login path available in case you need to restore your previous setup.
- Add a license file before granting permission to redistribute or reuse the project.
